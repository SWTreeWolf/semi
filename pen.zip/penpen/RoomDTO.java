package penpen;

public class RoomDTO {
	private int r_num;
	private String r_name;
	private int r_pay;
	private int r_limitedNumber;
	private String r_contents;
	
	public RoomDTO() {
	
		}

	public int getR_num() {
		return r_num;
	}

	public void setR_num(int r_num) {
		this.r_num = r_num;
	}

	public String getR_name() {
		return r_name;
	}

	public void setR_name(String r_name) {
		this.r_name = r_name;
	}

	public int getR_pay() {
		return r_pay;
	}

	public void setR_pay(int r_pay) {
		this.r_pay = r_pay;
	}

	public int getR_limitedNumber() {
		return r_limitedNumber;
	}

	public void setR_limitedNumber(int r_limitedNumber) {
		this.r_limitedNumber = r_limitedNumber;
	}

	public String getR_contents() {
		return r_contents;
	}

	public void setR_contents(String r_contents) {
		this.r_contents = r_contents;
	}

	
}//end class
