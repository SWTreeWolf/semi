

/* Drop Tables */

DROP TABLE Reservation CASCADE CONSTRAINTS;
DROP TABLE Person CASCADE CONSTRAINTS;
DROP TABLE Room CASCADE CONSTRAINTS;


/* Create Tables */

CREATE TABLE Person
(
   p_name varchar2(50) NOT NULL,
   p_num number NOT NULL,
   p_phoneNumber varchar2(50) NOT NULL,
   p_email varchar2(50) NOT NULL,
   p_contents varchar2(3000),
   PRIMARY KEY (p_name)
);


CREATE TABLE Reservation
(
   l_num number NOT NULL,
   l_date date NOT NULL,
   p_name varchar2(50) NOT NULL,
   r_num number NOT NULL,
   PRIMARY KEY (l_num)
);


insert into Reservation values(reserv_seq.nextval,TO_DATE('21-07-2019','DD-MM-YYYY'),'미나',789);
insert into Reservation values(reserv_seq.nextval,TO_DATE('2018-06-20','YYYY-MM-DD'),'미나',1);
insert into Reservation values(reserv_seq.nextval,TO_DATE('2018-06-21','YYYY-MM-DD'),'미나',1);
insert into Reservation values(reserv_seq.nextval,TO_DATE('2018-06-22','YYYY-MM-DD'),'미나',1);
insert into Reservation values(reserv_seq.nextval,TO_DATE('2018-06-25','YYYY-MM-DD'),'코코',2);
insert into Reservation values(reserv_seq.nextval,TO_DATE('2018-06-26','YYYY-MM-DD'),'코코',2);
insert into Reservation values(reserv_seq.nextval,TO_DATE('2018-06-27','YYYY-MM-DD'),'코코',2);

 insert into Reservation values(reserv_seq.nextval,TO_DATE('2018-06-21','YYYY-MM-DD'),'송이',3);
insert into Reservation values(reserv_seq.nextval,TO_DATE('2018-07-17','YYYY-MM-DD'),'휴휴',1);
 
 
/*선택한 날짜 & 방에 예약이 되어있는지 확인*/ 
 select * from reservation where l_date between TO_DATE('2018-06-27','YYYY-MM-DD') and TO_DATE('2018-06-27','YYYY-MM-DD')
 and r_num=2;
 
 
 /*선택한 날짜&방에 예약이 안되어있는 방 나타내기*/
 select * from room where r_num not in
 ( select r_num from reservation 
 where l_date between TO_DATE('2018-06-30','YYYY-MM-DD') and TO_DATE('2018-06-31','YYYY-MM-DD')
 and r_num=1)
 
select * from reservation;
CREATE TABLE Room
(
   r_num number NOT NULL,
   r_name varchar2(100) NOT NULL,
   r_pay number NOT NULL,
   r_limitedNumber number NOT NULL,
   r_contents varchar2(1000),
   PRIMARY KEY (r_num)
);


insert into room values(1,'1번방',90000,4,'정말정말 좋은방이에요^^ 너무너무너무 ㅠㅠㅠㅠㅠㅠㅠ흐흐그흐ㅡㄱ흐그흑');
insert into room values(2,'2번방!',120000,5,'비싸지만 좋은방입니다^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^6ㅇㅇㅅㅇㅅㅇㅅㅇㅅ케케케케케');
insert into room values(3,'3번방~',20000,2,'두명밖에 못 들어가는 방이에에요.... ');
/* Create Foreign Keys */

ALTER TABLE Reservation
   ADD FOREIGN KEY (p_name)
   REFERENCES Person (p_name)
;


ALTER TABLE Reservation
   ADD FOREIGN KEY (r_num)
   REFERENCES Room (r_num)
;

/* Create Sequence */
create sequence person_seq
start with 1
increment by 1
nocache
nocycle;

create sequence reserv_seq
start with 1
increment by 1
nocache
nocycle;

create sequence room_seq
start with 1
increment by 1
nocache
nocycle;
