package penpen;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;

public class ListAction {

	//빈방리스트
	@SuppressWarnings("unchecked")
	public void execute(HttpServletRequest req, HttpServletResponse resp)  throws ServletException, IOException {
		
		String dateIn=req.getParameter("dateIn");
		String dateOut=req.getParameter("dateOut");
		int r_num=Integer.parseInt(req.getParameter("guests"));
		
		System.out.println(dateIn); 
		System.out.println(dateOut);
		System.out.println(r_num);
		
		ReservationDAO dao=ReservationDAO.getInstance();
		List<RoomDTO> list=dao.getRoom(dateIn, dateOut, r_num);
		if(req.getParameter("ajax")==null) {
			req.setAttribute("list", list);
			System.out.println("에이젝스없는");
		}else {
			System.out.println("있는");
			JSONArray arr=new JSONArray();
			for(RoomDTO lis: list){
				JSONObject obj=new JSONObject();
				obj.put("r_name", lis.getR_name());
				obj.put("r_contents", lis.getR_contents());
				obj.put("r_num", lis.getR_num());
				obj.put("r_pay", lis.getR_pay());
				arr.add(obj);
			}
			resp.setContentType("text/json;charset=utf-8");
			resp.getWriter().print(arr);
			System.out.println(arr);
		}//end else
		
	}
	
}
