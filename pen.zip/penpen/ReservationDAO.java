package penpen;

import java.sql.*;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

public class ReservationDAO {
	private Connection conn;
	private Statement stmt;
	private PreparedStatement pstmt;
	private ResultSet rs;
	
	
	private ReservationDAO() {
		
	}
	private static ReservationDAO dao= new ReservationDAO();
	
	public static ReservationDAO getInstance() {
		return dao;
	}
	
	private Connection init() throws ClassNotFoundException, SQLException{
		Class.forName("oracle.jdbc.OracleDriver");
		String url="jebc:oracle:thin://@127.0.0.1:1521:xe";
		String user = "hr";
		String password="a1234";
		return DriverManager.getConnection(url,user,password);
	}//init
	
	private void exit() throws SQLException {
		if(rs!=null)
			rs.close();
		if(stmt!=null)
			stmt.close();
		if(pstmt!=null)
			pstmt.close();
		if(conn!=null)
			conn.close();
	}//exit
	
	
	//빈방 가져오기 ^^
	public List<RoomDTO> getRoom(String dat1,String dat2,int r_num){
		List<RoomDTO> list=new LinkedList<RoomDTO>();
		try {
			conn=init();
			String sql="select * from room where r_num not in" + 
					" (select r_num from reservation " + 
					" where l_date between TO_DATE(?,'YYYY-MM-DD') and TO_DATE(?,'YYYY-MM-DD')" + 
					" and r_num=?)";
			pstmt=conn.prepareStatement(sql);
			pstmt.setString(1, dat1);
			pstmt.setString(2, dat2);
			pstmt.setInt(3, r_num);
			rs=pstmt.executeQuery();
			while(rs.next()) {
				RoomDTO dto=new RoomDTO();
				dto.setR_num(rs.getInt("r_num"));
				dto.setR_name(rs.getString("r_name"));
				dto.setR_limitedNumber(rs.getInt("r_limitednumber"));
				dto.setR_contents(rs.getString("r_contents"));
				dto.setR_pay(rs.getInt("r_pay"));
				list.add(dto);
			}
		} catch (ClassNotFoundException | SQLException e) {
			e.printStackTrace();
		}
		
		return list;
	}
	
	
}
