package penpen;

import java.sql.Date;

public class ReservationDTO {
		private int l_num;
		private Date l_date;
		private String p_name;
		private int r_num;
		public int getL_num() {
			return l_num;
		}
		public void setL_num(int l_num) {
			this.l_num = l_num;
		}
		public Date getL_date() {
			return l_date;
		}
		public void setL_date(Date l_date) {
			this.l_date = l_date;
		}
		public String getP_name() {
			return p_name;
		}
		public void setP_name(String p_name) {
			this.p_name = p_name;
		}
		public int getR_num() {
			return r_num;
		}
		public void setR_num(int r_num) {
			this.r_num = r_num;
		}
	
		
}
