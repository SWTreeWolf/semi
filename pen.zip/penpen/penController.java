package penpen;

import java.io.IOException;
import java.sql.Date;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
@WebServlet("/penn/*")
public class penController extends HttpServlet{
	
	
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		doProcess(req,resp);
	}
	

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		doProcess(req,resp);
		
	}
	
	protected void doProcess(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		
		
		String uri=req.getRequestURI();	
		String action=uri.substring(uri.lastIndexOf("/"));
		String path="";
		if(action.equals("/*")||action.equals("/main.pen")) {//메인페이지
			path="/pen/pen1.jsp";
			System.out.println("메인페이지");
		}else if(action.equals("/list.pen")) {//빈방
			ListAction list=new ListAction();
			list.execute(req, resp);
			path="/pen/reserve.jsp";
		}else if(action.equals("/ajax.list")) {
			ListAction list=new ListAction();
			list.execute(req, resp);
		}
		
		
		if(path!="") {
			RequestDispatcher dis=req.getRequestDispatcher(path);
			System.out.println(path);
			dis.forward(req, resp);
			}
	}
}
